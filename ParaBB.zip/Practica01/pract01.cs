using System;
using System.Collections.Generic;
using System.Linq;

 class practica
{
    static void Main(string[] args)
{
    Console.WriteLine($"Text");
}
}