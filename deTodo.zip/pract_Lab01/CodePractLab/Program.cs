﻿using System;
/*
Ejercicio 1: Crea un array unidimensional de 10 números enteros aleatorios entre 1 y 100.
 Luego, ordena el array de forma ascendente usando el método Array.Sort() 
 y muestra el array ordenado por consola. Puedes usar la clase Random para 
 generar números aleatorios.

Ejercicio 2: Crea un array bidimensional de 3 filas y 4 columnas que represente una matriz
 de números enteros. Luego, calcula y muestra por consola la suma de cada fila, la suma de 
 cada columna y la suma total de la matriz. Puedes usar bucles anidados para recorrer el array.

Ejercicio 3: Crea un array tridimensional de 2 páginas, 3 filas y 4 columnas que represente
 una colección de matrices de números enteros. Luego, muestra por consola cada matriz con su
  número de página y sus elementos. Puedes usar tres bucles anidados para recorrer el array.*/

class Ejercicio
{


    private static int Random()
    {
        Random rdm = new();
        return rdm.Next(0, 100);
    }

    private static void Ver(int[] arry)
    {
        foreach (var item in arry)
        {

            Console.Write("[ " + item + " ]");

        }

    }

    private static void Ver3x4(int[,] arry,int xx,int yy)
    {

        int sumX = 0, sumY = 0, sumA = 0, o = 0;
        int[] sumaX = new int[xx];
        int[] sumaY = new int[yy];
        int[] sumaT = new int[xx+yy];



        for (int i = 0; i < xx; i++)
        {
            for (int ii = 0; ii < yy; ii++)
            {
                sumX += arry[i, ii];//suma de la las posiciones de columnas
                sumaX[i] = sumX;//agregar la sumatoria de una columna a un array

            }
            sumA += sumX;

            sumX = 0;


        }

        for (int i = 0; i < yy; i++)
        {
            for (int ii = 0; ii < xx; ii++)
            {
                sumY += arry[ii, i];//suma de la las posiciones de columnas
                sumaY[i] = sumY;//agregar la sumatoria de una columna a un array

            }
            sumY = 0;

        }

        foreach (var item in sumaT)
        {
            sumA += item;
        }

        for (int i = 0; i < xx; i++)
        {
            for (int ii = 0; ii < yy; ii++)
            {
                Console.Write("[ " + arry[i, ii] + " ] ");

            }
            System.Console.WriteLine(@"( " + sumaX[i] + " ) ");



            System.Console.WriteLine();
        }
        for (int ii = 0; ii < yy; ii++)
        {
            System.Console.Write(@"( " + sumaY[ii] + ") ");

        }

        System.Console.WriteLine($"\n\nsumatoria total de la matriz de [ {xx}*{yy} ] es : " + sumA);

    }


    public static void Main(string[] args)
    {
/*
        int[] arry01 = new int[10];
        for (int i = 0; i < 10; i++)
        {
            arry01[i] = Random();
        }
        Console.WriteLine($"Ejercicio 01\n");
        Ver(arry01);
        Console.WriteLine("\n\n");
        

        Console.WriteLine(@"  EJERCICIO 2: 
Crea un array bidimensional con dimenciones ingresadas por terminal,
que represente una matriz de números enteros. Luego, calcula y muestra por consola la suma de cada fila,
la suma de cada columna y la suma total de la matriz." + "\n\n");

int x,y;
Console.Write($"ingrese numero de filas: ");
x= int.Parse(Console.ReadLine());
Console.Write($"ingrese numero de columnas: ");
y= int.Parse(Console.ReadLine());
Console.WriteLine($"---------------------------------------");


        int[,] arry02 = new int[x, y];

        for (int i = 0; i < x; i++)
        {
            for (int ii = 0; ii < y; ii++)
            {
                arry02[i, ii] = Random();
            }
        }

        Ver3x4(arry02,x,y);*/

    Console.WriteLine($"ejercicio 3");
    System.Console.WriteLine(@"Crea un array tridimensional de 3 páginas, 3 filas y 3 columnas que represente
 una colección de matrices de números enteros. Luego, muestra por consola cada matriz con su
  número de página y sus elementos");

    int [,,] arry03 = new int[3,3,3];

        for (int i = 0; i < 3; i++)
        {
            for (int ii = 0; ii < 3; ii++)
            {
            for (int iii = 0; iii < 3; iii++)
            {
                arry03[i, ii,iii] = Random();
            }
        }
    }
int sumP =0,sumC=0,sumF=0;
int[] SUMp = new int[3];

    for (var i = 0; i < 3; i++)
    {
        for (var ii = 0; ii < 3; ii++)
        {
            for (var iii = 0; iii < 3; iii++)
            {

                sumP += arry03[i,ii,iii];
            }
        }
        SUMp[i] =sumP;sumP=0;
        
    }

        for (var i = 0; i < 3; i++)
    {
        for (var ii = 0; ii < 3; ii++)
        {
            for (var iii = 0; iii < 3; iii++)
            {
                sumC += arry03[ii,i,iii];
            }
        }
    }

        for (var i = 0; i < 3; i++)
    {
        for (var ii = 0; ii < 3; ii++)
        {
            for (var iii = 0; iii < 3; iii++)
            {
                sumF += arry03[iii,i,ii];
            }
        }
    }

System.Console.WriteLine();
    for (var i = 0; i < 3; i++)
    {
                System.Console.WriteLine($"Total de Pag. {i+1} es: {SUMp[i]}\n");
        for (var ii = 0; ii < 3; ii++)
        {
            for (var iii = 0; iii < 3; iii++)
            {
                Console.Write("\t[ " + arry03[i,ii,iii]+" ]");
            }
        System.Console.WriteLine("\n");
        }
    }

    }
}